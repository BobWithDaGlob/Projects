#ifndef STACKS_H
#define STACKS_H

#include <iostream>
using namespace std;

// Node structure to store elements in the queue
struct StacksNode {
    int data;
    StacksNode* next;

    
    StacksNode(int d, StacksNode* n = nullptr) : data(d), next(n) {}
};


class Queue {
private:
    StacksNode* front;  
    StacksNode* rear;   

public:
    
    Queue() : front(nullptr), rear(nullptr) {}

    
    ~Queue() {
        while (dequeue()) {} 
    }

   
    void enqueue(int data);

    
    bool dequeue();

    
    bool peek(int& data);

    
    void display(ostream& os);

    
    void view(ostream& os);
};

#endif


