#pragma once
class StacksNode
{
	public:
		int data;
		StacksNode* next;

		StacksNode() : data(0), next(nullptr){}
		StacksNode(int data): data(data), next(nullptr){}
		StacksNode(int data, StacksNode* next): data(data), next(next){}

};

