#include "Stacks.h"
#include <iostream>
using namespace std;


void Queue::enqueue(int data) {
    StacksNode* newNode = new StacksNode(data);

    if (rear == nullptr) {  
        front = rear = newNode;
    } else {
        rear->next = newNode;  
        rear = newNode;        
    }
}


bool Queue::dequeue() {
    if (front == nullptr) return false;  

    StacksNode* tmp = front;
    front = front->next;  

    if (front == nullptr) {  
        rear = nullptr;
    }

    delete tmp;  
    return true;
}


bool Queue::peek(int& data) {
    if (front == nullptr) {
        cout << "Queue is empty!" << endl;
        return false;  
    }
    data = front->data;  
    return true;
}


void Queue::display(ostream& os) {
    StacksNode* tmp = front;
    while (tmp != nullptr) {
        os << tmp->data << " ";
        tmp = tmp->next;
    }
    os << endl;
}


void Queue::view(ostream& os) {
    StacksNode* tmp = front;
    os << "\nQueue contents (front to end):" << endl;
    while (tmp != nullptr) {
        os << tmp->data << endl;
        tmp = tmp->next;
    }
}
